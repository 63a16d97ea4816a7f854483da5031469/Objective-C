//
//  PopAnimator.h
//  Popping
//
//  Created by André Schneider on 14.05.14.
//  Copyright (c) 2014 André Schneider. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PresentingAnimator : NSObject <UIViewControllerAnimatedTransitioning>

@end
