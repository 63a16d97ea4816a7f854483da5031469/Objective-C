//
//  AppDelegate.h
//  M13ProgressView
//
//  Created by Brandon McQuilkin on 11/18/13.
//  Copyright (c) 2013 Brandon McQuilkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
