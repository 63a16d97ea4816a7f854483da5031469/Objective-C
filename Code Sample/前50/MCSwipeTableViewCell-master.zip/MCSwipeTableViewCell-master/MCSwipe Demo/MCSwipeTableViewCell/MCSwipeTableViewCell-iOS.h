//
//  MCSwipeTableViewCell.h
//  MCSwipeTableViewCell
//
//  Created by Ali Karagoz on 18/07/15.
//  Copyright (c) 2015 Mad Castle. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MCSwipeTableViewCell.
FOUNDATION_EXPORT double MCSwipeTableViewCellVersionNumber;

//! Project version string for MCSwipeTableViewCell.
FOUNDATION_EXPORT const unsigned char MCSwipeTableViewCellVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MCSwipeTableViewCell/PublicHeader.h>


