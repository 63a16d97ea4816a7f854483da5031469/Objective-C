//
//  AppDelegate.h
//  JBChartViewDemo
//
//  Created by Terry Worona on 10/30/13.
//  Copyright (c) 2013 Jawbone. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
