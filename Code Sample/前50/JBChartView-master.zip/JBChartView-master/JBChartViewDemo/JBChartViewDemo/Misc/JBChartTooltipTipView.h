//
//  JBChartTooltipTipView.h
//  JBChartViewDemo
//
//  Created by Terry Worona on 3/17/14.
//  Copyright (c) 2014 Jawbone. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JBChartTooltipTipView : UIView

@end
