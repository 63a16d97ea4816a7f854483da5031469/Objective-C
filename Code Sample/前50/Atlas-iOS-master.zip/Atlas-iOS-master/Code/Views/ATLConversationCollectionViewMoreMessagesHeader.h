//
//  ATLUIConversationCollectionViewMoreMessagesHeader.h
//  Atlas
//
//  Created by Ben Blakley on 1/15/15.
//  Copyright (c) 2015 Layer, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString *__nonnull const ATLMoreMessagesHeaderIdentifier;

@interface ATLConversationCollectionViewMoreMessagesHeader : UICollectionReusableView

@end
