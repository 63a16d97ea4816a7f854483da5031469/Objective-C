//
//  AMViewController.h
//  blur
//
//  Created by Cesar Pinto Castillo on 8/2/13.
//  Copyright (c) 2013 Arctic Minds Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMViewController : UIViewController

@end
