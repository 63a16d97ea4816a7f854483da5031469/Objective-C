//
//  PJXTransitionItemAnimations.h
//  PJXAnimatedTabBarDemo
//
//  Created by poloby on 15/12/31.
//  Copyright © 2015年 poloby. All rights reserved.
//

#import "PJXItemAnimation.h"

@interface PJXTransitionItemAnimations : PJXItemAnimation
@property (nonatomic, assign) UIViewAnimationOptions transitionOptions;
@end