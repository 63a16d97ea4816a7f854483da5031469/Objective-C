//
//  PJXFlipBottomTransitionItemAnimations.h
//  PJXAnimatedTabBarDemo
//
//  Created by poloby on 15/12/31.
//  Copyright © 2015年 poloby. All rights reserved.
//

#import "PJXTransitionItemAnimations.h"

@interface PJXFlipBottomTransitionItemAnimations : PJXTransitionItemAnimations

@end
