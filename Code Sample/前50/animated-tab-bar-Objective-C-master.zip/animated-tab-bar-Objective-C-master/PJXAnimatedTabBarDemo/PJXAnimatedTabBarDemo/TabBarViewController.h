//
//  TabBarViewController.h
//  PJXAnimatedTabBarDemo
//
//  Created by poloby on 16/4/16.
//  Copyright © 2016年 poloby. All rights reserved.
//

#import "PJXAnimatedTabBarController.h"

@interface TabBarViewController : PJXAnimatedTabBarController

@end
