//
//  main.m
//  MCActivityButton
//
//  Created by Marcos Curvello on 04/24/2015.
//  Copyright (c) 2014 Marcos Curvello. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MCActivityButtonAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MCActivityButtonAppDelegate class]));
    }
}
