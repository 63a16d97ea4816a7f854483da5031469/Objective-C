//
//  MCActivityButtonAppDelegate.h
//  MCActivityButton
//
//  Created by CocoaPods on 04/24/2015.
//  Copyright (c) 2014 Marcos Curvello. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MCActivityButtonAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
