//
//  MCActivityButtonViewController.h
//  MCActivityButton
//
//  Created by Marcos Curvello on 04/24/2015.
//  Copyright (c) 2014 Marcos Curvello. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MCActivityButton/MCActivityButton.h>


@interface MCActivityButtonViewController : UIViewController

@property (nonatomic, strong) MCActivityButton *activityButton;

@end
