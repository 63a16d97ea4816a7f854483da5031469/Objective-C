# Change Log
All notable changes to this project will be documented in this file.
`BubbleTransition` adheres to [Semantic Versioning](http://semver.org/).

- `0.6.x` Releases - [0.6.0](#060) | [0.6.1](#061) | [0.6.2](#062)  
- `0.5.x` Releases - [0.5.7](#057)

---

## [0.6.2](https://github.com/andreamazz/AMWaveTransition/releases/tag/0.6.2)

###Fixed
- Rendering issues    

## [0.6.1](https://github.com/andreamazz/AMWaveTransition/releases/tag/0.6.1)

###Fixed
- Minor fixes  
- Improved doc 

## [0.6.0](https://github.com/andreamazz/AMWaveTransition/releases/tag/0.6.0)

###Added
- Carthage support  

## [0.5.7](https://github.com/andreamazz/AMWaveTransition/releases/tag/0.5.7)

