//
//  AMWaveTransition.h
//  AMWaveTransition
//
//  Created by Andrea Mazzini on 14/08/15.
//  Copyright (c) 2015 Fancy Pixel. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AMWaveTransition.
FOUNDATION_EXPORT double AMWaveTransitionVersionNumber;

//! Project version string for AMWaveTransition.
FOUNDATION_EXPORT const unsigned char AMWaveTransitionVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AMWaveTransition/PublicHeader.h>
#import <AMWaveTransition/AMWaveTransition.h>
#import <AMWaveTransition/AMWaveViewController.h>
