//
//  ViewController.h
//  RNLoadingButtonDemo
//
//  Created by Romilson Nunes on 02/07/14.
//  Copyright (c) 2014 Romilson Nunes. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
