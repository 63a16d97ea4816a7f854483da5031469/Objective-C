//
//  IFTTTJazzHandsAppDelegate.m
//  JazzHandsDemo
//
//  Created by Devin Foley on 9/27/13.
//  Copyright (c) 2013 IFTTT Inc. All rights reserved.
//

#import "IFTTTJazzHandsAppDelegate.h"

#import "IFTTTJazzHandsViewController.h"

@implementation IFTTTJazzHandsAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end
