// For License please refer to LICENSE file in the root of YALAnimatingTabBarController project

#import <UIKit/UIKit.h>

@interface YALCustomHeightTabBar : UITabBar

@property (nonatomic) CGFloat barHeight;

@end
