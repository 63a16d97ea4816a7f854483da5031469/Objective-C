// For License please refer to LICENSE file in the root of YALAnimatingTabBarController project

#import <UIKit/UIKit.h>

//! Project version number for FoldingTabBar.
FOUNDATION_EXPORT double FoldingTabBarVersionNumber;

//! Project version string for FoldingTabBar.
FOUNDATION_EXPORT const unsigned char FoldingTabBarVersionString[];
