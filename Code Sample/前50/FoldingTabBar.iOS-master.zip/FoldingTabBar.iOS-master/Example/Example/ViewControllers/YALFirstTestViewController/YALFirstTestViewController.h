// For License please refer to LICENSE file in the root of YALAnimatingTabBarController project

#import <UIKit/UIKit.h>

#import "YALFoldingTabBar.h"

@interface YALFirstTestViewController : UIViewController <YALTabBarDelegate>

@end
