//
//  main.m
//  PathIntro
//
//  Created by Dmitry Kondratyev on 29.04.13.
//  Copyright (c) 2013 Dmitry Kondratyev. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
