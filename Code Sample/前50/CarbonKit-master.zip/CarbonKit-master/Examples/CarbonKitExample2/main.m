//
//  main.m
//  CarbonKitExample2
//
//  Created by 최완복 on 2015. 11. 25..
//  Copyright © 2015년 Ermal Kaleci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
