//
//  AppDelegate.h
//  CarbonKitExample2
//
//  Created by 최완복 on 2015. 11. 25..
//  Copyright © 2015년 Ermal Kaleci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

