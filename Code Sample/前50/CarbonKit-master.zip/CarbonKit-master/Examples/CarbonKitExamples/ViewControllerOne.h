#import <UIKit/UIKit.h>


@interface ViewControllerOne : UIViewController

@property(nonatomic, retain) IBOutlet UITableView *tableView;

@end
