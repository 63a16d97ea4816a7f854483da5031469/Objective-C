#import <UIKit/UIKit.h>


@interface ViewControllerTwo : UIViewController
@property(weak, nonatomic) IBOutlet UICollectionView *collectionView;

@end
