//
//  JGDetailViewController.h
//  JGProgressHUD Tests
//
//  Created by Jonas Gessner on 06.08.16.
//  Copyright © 2016 Jonas Gessner. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JGDetailViewController : UIViewController

@end
