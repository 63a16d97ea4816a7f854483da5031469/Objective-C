//
//  RearTableViewController.h
//  RevealControllerProject3
//
//  Created by Joan on 30/12/12.
//
//

#import <UIKit/UIKit.h>

@interface RearTableViewController : UITableViewController

@end
