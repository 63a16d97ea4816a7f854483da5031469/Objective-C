//
//  ChainableANimationsSwiftExample-Bridging-Header.h
//  ChainableAnimationsWithSwiftExample
//
//  Created by Jeff Hurray on 5/11/15.
//  Copyright (c) 2015 jhurray. All rights reserved.
//

#ifndef ChainableAnimationsWithSwiftExample_ChainableAnimationsSwiftExample_Bridging_Header_h
#define ChainableAnimationsWithSwiftExample_ChainableAnimationsSwiftExample_Bridging_Header_h

#import "JHChainableAnimations.h"

#endif
