//
//  ViewController.h
//  摇一摇
//
//  Created by nacker on 15/1/22.
//  Copyright (c) 2015年 帶頭二哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

