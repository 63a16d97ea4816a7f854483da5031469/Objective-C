//
//  ViewController.m
//  UITableView拉伸效果
//
//  Created by xindong on 16/1/2.
//  Copyright © 2016年 xindong. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDataSource, UITableViewDelegate, UIScrollViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIImageView *headerImgaeView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 568) style:UITableViewStyleGrouped];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    
    [self layoutHeaderImageView];
}

- (void)layoutHeaderImageView
{
    UIView *headerBackView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 150)];
    headerBackView.backgroundColor = [UIColor lightGrayColor];
    self.tableView.tableHeaderView = headerBackView;
    
    self.headerImgaeView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 150)];
    self.headerImgaeView.backgroundColor = [UIColor greenColor];
    self.headerImgaeView.image = [UIImage imageNamed:@"beautiful.jpg"];
    self.headerImgaeView.contentMode = UIViewContentModeScaleAspectFill;
    self.headerImgaeView.clipsToBounds = YES;
    [headerBackView addSubview:self.headerImgaeView];

}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat width = self.view.frame.size.width;// 图片宽度
    CGFloat yOffset = scrollView.contentOffset.y; //偏移量
    
    NSLog(@":  %.2f", yOffset);
    
    if (yOffset < 0) {
        CGFloat totalOffset = 150 + ABS(yOffset);
        CGFloat f = totalOffset / 150; //缩放系数
        
        self.headerImgaeView.frame = CGRectMake(-(width * f - width) / 2, yOffset, width * f, totalOffset); //拉伸后的frame是同比例缩放
    }
    
    if (yOffset > 0) {
        CGFloat totalOffset = 150 - ABS(yOffset);
        CGFloat f = totalOffset / 150;
        
        self.headerImgaeView.frame = CGRectMake(-(width * f - width) / 2, yOffset, width * f, totalOffset);
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *reuseIndentify = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIndentify];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuseIndentify];
    }
    cell.textLabel.text = @"心董儿";
    cell.detailTextLabel.text = @"2016-01-02";
    return  cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



























- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
