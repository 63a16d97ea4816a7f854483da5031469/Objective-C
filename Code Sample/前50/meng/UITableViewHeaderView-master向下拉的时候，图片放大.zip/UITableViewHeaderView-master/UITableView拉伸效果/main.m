//
//  main.m
//  UITableView拉伸效果
//
//  Created by xindong on 16/1/2.
//  Copyright © 2016年 xindong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
