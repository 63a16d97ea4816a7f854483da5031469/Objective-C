//
//  LocalisatorViewController.h
//  CustomLocalisator
//
//  Created by Michael Azevedo on 06/03/2014.
//
//

#import <UIKit/UIKit.h>

@interface LocalisatorViewController : UIViewController

@end
