//
//  UIView+CoreListLayout.h
//  CoreList
//
//  Created by 冯成林 on 15/11/28.
//  Copyright © 2015年 muxi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (NFLayout)

-(void)autoLayoutFillSuperView;

@end
