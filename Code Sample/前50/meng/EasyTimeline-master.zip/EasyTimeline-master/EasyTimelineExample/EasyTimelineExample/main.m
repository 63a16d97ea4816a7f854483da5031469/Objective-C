//
//  main.m
//  EasyTimelineExample
//
//  Created by Mohammed Islam on 2/26/14.
//  Copyright (c) 2014 KSI Technology. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ETAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([ETAppDelegate class]));
	}
}
