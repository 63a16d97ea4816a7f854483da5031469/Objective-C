//
//  ETViewController.h
//  EasyTimelineExample
//
//  Created by Mohammed Islam on 2/26/14.
//  Copyright (c) 2014 KSI Technology. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ETViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@end
