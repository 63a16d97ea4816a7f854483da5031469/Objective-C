//
//  ETViewControllerExamplePause.h
//  EasyTimelineExample
//
//  Created by Mohammed Islam on 2/28/14.
//  Copyright (c) 2014 KSI Technology. All rights reserved.
//

#import "ETViewControllerExample.h"

@interface ETViewControllerExamplePause : ETViewControllerExample
{
	NSInteger _tickNumber;
}

@end
