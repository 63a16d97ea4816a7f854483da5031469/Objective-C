//
//  ETViewControllerExampleEvents.h
//  EasyTimelineExample
//
//  Created by Mohammed Islam on 2/27/14.
//  Copyright (c) 2014 KSI Technology. All rights reserved.
//

#import "ETViewControllerExample.h"

@interface ETViewControllerExampleEvents : ETViewControllerExample

@end
