//
//  DKAppDelegate.h
//  DKFilterView
//
//  Created by CocoaPods on 01/07/2015.
//  Copyright (c) 2014 Drinking. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
