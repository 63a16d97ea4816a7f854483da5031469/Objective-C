//
//  main.m
//  DKFilterView
//
//  Created by Drinking on 01/07/2015.
//  Copyright (c) 2014 Drinking. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "DKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([DKAppDelegate class]));
    }
}
