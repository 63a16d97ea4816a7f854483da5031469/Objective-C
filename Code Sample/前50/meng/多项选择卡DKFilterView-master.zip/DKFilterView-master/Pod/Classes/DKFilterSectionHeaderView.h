//
//  DKFilterSectionHeaderView.h
//  Partner
//
//  Created by Drinking on 15-1-5.
//  Copyright (c) 2015年 zhinanmao.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DKFilterSectionHeaderView : UIView

- (void)setSectionHeaderTitle:(NSString *)title;
@end
