//
//  ExceptionConst.m
//  Exception
//
//  Created by muxi on 15/1/22.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import "CoreExceptionConst.h"

NSString *const CoreExceptionArray = @"__NSArrayI";                                             //NSArray

NSString *const CoreExceptionArrayM = @"__NSArrayM";                                            //NSMutableArray

NSString *const CoreExceptionString = @"__NSCFConstantString";                                  //NSString





