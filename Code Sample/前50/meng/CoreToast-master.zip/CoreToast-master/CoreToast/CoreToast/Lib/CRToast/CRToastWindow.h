//
//  CRToastWindow.h
//  CRToastDemo
//
//  Created by Daniel on 12/19/14.
//  Copyright (c) 2014 Collin Ruffenach. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CRToastWindow : UIWindow

@end
