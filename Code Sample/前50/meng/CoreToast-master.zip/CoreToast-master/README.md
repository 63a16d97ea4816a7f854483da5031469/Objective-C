
    Charlin出框架的目标：简单、易用、实用、高度封装、绝对解耦！

# CoreToast
    基于CRToast的封装，更好用！
<br />
####框架特性：<br />
>1.基于CRToast的封。<br />
>2.增加了开始及结束回调。<br />
>3.注重线程管理。<br />
>4.强化触发控件的管理。<br />




<br /><br />


-----
    CoreToast 基于CRToast的封装，更好用！
-----

<br /><br />

#### 版权说明 RIGHTS <br />
作品说明：本框架由iOS开发攻城狮Charlin制作。<br />
作品时间： 2013.03.07 18:07<br />


#### 关于Chariln INTRODUCE <br />
作者简介：Charlin-四川成都华西都市报旗下华西都市网络有限公司技术部iOS工程师！<br /><br />


#### 联系方式 CONTACT <br />
Q    Q：1761904945（请注明缘由）<br />
Mail：1761904945@qq.com<br />
