//
//  ViewController2.h
//  DSAlertDemo
//
//  Created by boai on 16/8/31.
//  Copyright © 2016年 DS-Team. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController2 : UIViewController

@end
