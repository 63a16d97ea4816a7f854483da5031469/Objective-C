//
//  RoboReader.h
//  RoboReader
//
//  Created by Mikhail Viceman on 26.03.13.
//  Copyright (c) 2012 REDMADROBOT. All rights reserved.
//

#ifndef RoboReader_RoboReader_h
#define RoboReader_RoboReader_h

#import "RoboViewController.h"

#endif
