
    Charlin出框架的目标：简单、易用、实用、高度封装、绝对解耦！

# CoreMediaFuncManagerVC
    一句代码完成多媒体打电话！
<br />
####框架特性：<br />
>1.多媒体功能一句代码搞定。<br />
>2.目前支持一句代码打电话。<br />
>3.无需考虑任何协议，只需给一个号码即可。<br />
>4.无需考虑生命周期，已经全部考虑好，你只管用即可。<br />
>5.拨打完电话仍然会回到当前app，留住用户。<br />
>6.无需任何成员变量记录，使用极其简单。<br />
>7.更多相关多媒体功能即将完善，敬请期待。<br />




<br /><br />
####使用示例：<br />

        [CoreMediaFuncManagerVC call:@"10086" inViewController:self failBlock:^{
          NSLog(@"不能打");
        }];

<br /><br />


-----
    CoreMediaFuncManagerVC 一句代码完成多媒体打电话！！
-----

<br /><br />

#### 版权说明 RIGHTS <br />
作品说明：本框架由iOS开发攻城狮Charlin制作。<br />
作品时间： 2013.03.11 11:07<br />


#### 关于Chariln INTRODUCE <br />
作者简介：Charlin-四川成都华西都市报旗下华西都市网络有限公司技术部iOS工程师！<br /><br />


#### 联系方式 CONTACT <br />
Q    Q：1761904945（请注明缘由）<br />
Mail：1761904945@qq.com<br />
