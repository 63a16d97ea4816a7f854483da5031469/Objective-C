//
//  DGActivityIndicatorTwoDotsAnimation.h
//  DGActivityIndicatorExample
//
//  Created by Danil Gontovnik on 5/24/15.
//  Copyright (c) 2015 Danil Gontovnik. All rights reserved.
//

#import "DGActivityIndicatorAnimationProtocol.h"

@interface DGActivityIndicatorTwoDotsAnimation : NSObject <DGActivityIndicatorAnimationProtocol>

@end
