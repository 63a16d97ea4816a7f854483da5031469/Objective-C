//
//  NSData+MimeType.h
//  CoreHttp
//
//  Created by muxi on 15/3/2.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSData (MimeType)

@property (nonatomic,copy,readonly) NSString *mimeType;


@end
