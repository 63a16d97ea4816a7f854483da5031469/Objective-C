//
//  AppDelegate.h
//  YUKitSample
//
//  Created by BruceYu on 16/1/5.
//  Copyright © 2016年 BruceYu. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "vendors.h"
#import "YUKitHeader.h"
#import "BaseTableViewController.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

