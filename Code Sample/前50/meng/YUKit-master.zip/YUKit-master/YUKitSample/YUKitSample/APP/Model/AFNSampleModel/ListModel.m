//
//  ListModel.m
//  YUKitSample
//
//  Created by BruceYu on 16/1/12.
//  Copyright © 2016年 BruceYu. All rights reserved.
//

#import "ListModel.h"

@implementation ListModel

@end
