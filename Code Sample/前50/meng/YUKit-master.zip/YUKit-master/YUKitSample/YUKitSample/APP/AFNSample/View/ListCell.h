//
//  ListCell.h
//  YUKit
//  Created by BruceYu on 15/12/14.
//  Copyright © 2015年 BruceYu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ListModel.h"


@interface ListCell : UITableViewCell

@property (nonatomic,strong)ListModel *model;

@end
