//
//       \\     //    ========     \\    //
//        \\   //          ==       \\  //
//         \\ //         ==          \\//
//          ||          ==           //\\
//          ||        ==            //  \\
//          ||       ========      //    \\
//
//  SystemInformationViewController.h
//  YUKit
//
//  Created by BruceYu on 15/12/15.
//  Copyright © 2015年 BruceYu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface SystemInformationViewController: BaseTableViewController

@end
