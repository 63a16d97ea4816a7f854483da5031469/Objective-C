//
//  YU_AmountTextField.h
//  YUKit<https://github.com/c6357/YUKit>
//
//  Created by BruceYu on 15/9/7.
//  Copyright (c) 2015年 BruceYu. All rights reserved.
//

#import <UIKit/UIKit.h>

#define YU_AMOUNTTEXTFIELD_MAX_LENTH 10

/**
 * 金额输入 默认小数点二位. 整数位10位
 */

@interface YUAmountTextField : UITextField

@end
