//
//  BaseViewModel.m
//  YUKit<https://github.com/c6357/YUKit>
//
//  Created by BruceYu on 15/4/2.
//  Copyright (c) 2015年 BruceYu. All rights reserved.
//

#import "BaseViewModel.h"


@implementation BaseViewModel
{
#ifdef private_dictCustomerProperty
     NSMutableDictionary *_dictCustomerProperty;
#endif
}
@end
