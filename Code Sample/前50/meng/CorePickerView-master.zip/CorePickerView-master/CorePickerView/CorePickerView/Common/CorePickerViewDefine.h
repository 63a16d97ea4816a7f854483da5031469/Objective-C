//
//  CorePickerViewDefine.h
//  CorePickerView
//
//  Created by 冯成林 on 15/3/25.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#ifndef CorePickerView_CorePickerViewDefine_h
#define CorePickerView_CorePickerViewDefine_h

#define rgba(r,g,b,a) [UIColor colorWithRed:r/255.0f green:g/255.0f blue:b/255.0f alpha:a]

#define PickerViewBgColor rgba(249,249,249,.95f)

#endif
