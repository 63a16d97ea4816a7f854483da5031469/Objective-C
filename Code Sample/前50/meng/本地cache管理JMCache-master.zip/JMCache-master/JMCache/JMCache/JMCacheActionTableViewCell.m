//
//  JMCacheActionTableViewCell.m
//  JMCache
//
//  Created by jerome morissard on 02/08/14.
//  Copyright (c) 2014 jerome morissard. All rights reserved.
//

#import "JMCacheActionTableViewCell.h"

@implementation JMCacheActionTableViewCell

@end
