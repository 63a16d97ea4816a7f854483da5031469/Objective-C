//
//  JMCacheValueTransformer.h
//  JMCache
//
//  Created by jerome morissard on 27/07/14.
//  Copyright (c) 2014 jerome morissard. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JMCacheValueTransformer : NSValueTransformer

@end
