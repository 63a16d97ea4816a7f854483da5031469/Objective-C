//
//  AppDelegate.h
//  SafeKitExample
//
//  Created by zhangyu on 16/2/16.
//  Copyright © 2016年 zhangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

