//
//  SKMainViewController.h
//  SafeKitExample
//
//  Created by zhangyu on 14-3-20.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SKViewController.h"
@interface SKMainViewController : SKViewController

@end
