//
//  SKViewController.h
//  SafeKitExample
//
//  Created by zhangyu on 14-3-20.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SKViewController : UIViewController

@end
