//
//  NSArray+SafeKit.h
//  SafeKitExample
//
//  Created by zhangyu on 14-2-28.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//


#import <Foundation/Foundation.h>

@interface NSArray(SafeKit)

@end

