//
//  Foundation+SafeKit.h
//  SafeKitExample
//
//  Created by zhangyu on 14-2-28.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import "NSArray+SafeKit.h"
#import "NSMutableArray+SafeKit.h"

#import "NSMutableDictionary+SafeKit.h"

#import "NSString+SafeKit.h"
#import "NSMutableString+SafeKit.h"

#import "NSNumber+SafeKit.h"