//
//  NSNumber+SafeKit.h
//  JMBFramework
//
//  Created by zhangyu on 14-6-12.
//  Copyright (c) 2014年 jion-cheer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (SafeKit)

@end
