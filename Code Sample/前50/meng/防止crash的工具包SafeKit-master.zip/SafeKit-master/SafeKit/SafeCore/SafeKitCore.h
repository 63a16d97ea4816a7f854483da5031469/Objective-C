//
//  SafeKitCore.h
//  SafeKitExample
//
//  Created by zhangyu on 14-3-15.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//

#import "NSObject+swizzle.h"
#import "SafeKitMacro.h"