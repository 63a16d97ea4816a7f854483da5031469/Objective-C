//
//  SafeKit.h
//  SafeKitExample
//
//  Created by zhangyu on 14-2-28.
//  Copyright (c) 2014年 zhangyu. All rights reserved.
//



#ifndef _SafeKit_
#define _SafeKit_

#import "SafeKitCore.h"
#import "Foundation+SafeKit.h"

#endif /* _SafeKit_ */