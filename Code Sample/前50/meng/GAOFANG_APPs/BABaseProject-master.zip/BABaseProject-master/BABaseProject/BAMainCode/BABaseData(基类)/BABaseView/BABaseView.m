//
//  BABaseView.m
//  BABaseProject
//
//  Created by 博爱 on 16/5/4.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseView.h"

@implementation BABaseView

//- (instancetype)initWithFrame:(CGRect)frame
//{
//    if (self = [super initWithFrame:frame])
//    {
//        self.backgroundColor = BA_White_Color;
////        self.alpha = 0.0f;
//    }
//    return self;
//}



@end
