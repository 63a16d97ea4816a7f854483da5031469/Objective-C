//
//  DemoVC11_Cell.h
//  BABaseProject
//
//  Created by 博爱 on 16/6/2.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DemoVC11_model;
@interface DemoVC11_Cell : UICollectionViewCell

@property (nonatomic, strong) DemoVC11_model  *model;
@property (nonatomic, strong) UILabel         *titleLabel;

@end
