//
//  BANewFeatureVC.h
//  BABaseProject
//
//  Created by boai on 16/8/5.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseViewController.h"

@interface BANewFeatureVC : BABaseViewController

@end
