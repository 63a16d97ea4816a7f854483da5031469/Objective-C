//
//  BAPublishViewController.h
//  BABaseProject
//
//  Created by 博爱之家 on 16/6/11.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseViewController.h"

@interface BAPublishViewController : BABaseViewController

@end
