//
//  BADiscoverViewController.h
//  BABaseProject
//
//  Created by 博爱 on 16/5/3.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseViewController.h"

@interface BADiscoverViewController : BABaseViewController

@end
