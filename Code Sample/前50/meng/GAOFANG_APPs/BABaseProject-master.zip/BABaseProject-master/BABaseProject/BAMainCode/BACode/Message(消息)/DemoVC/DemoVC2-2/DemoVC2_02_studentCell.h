//
//  DemoVC2_02_studentCell.h
//  BABaseProject
//
//  Created by 博爱 on 16/7/20.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseCell.h"

@interface DemoVC2_02_studentCell : BABaseCell

- (void)ba_showSelectedAnimation;


@end
