//
//  DemoVC10Cell.h
//  BABaseProject
//
//  Created by 博爱 on 16/5/30.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DemoVC10Model;
@interface DemoVC10Cell : UICollectionViewCell

@property (nonatomic, strong) DemoVC10Model *model;

/*! cell右上角的删除按钮 */
@property (nonatomic, strong) UIButton      *deleteButton;

@end
