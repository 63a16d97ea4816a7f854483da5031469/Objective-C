//
//  DemoVC6.h
//  BABaseProject
//
//  Created by 博爱 on 16/5/14.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseViewController.h"

@interface DemoVC6 : BABaseViewController

- (void)reloadNotiView;

@end
