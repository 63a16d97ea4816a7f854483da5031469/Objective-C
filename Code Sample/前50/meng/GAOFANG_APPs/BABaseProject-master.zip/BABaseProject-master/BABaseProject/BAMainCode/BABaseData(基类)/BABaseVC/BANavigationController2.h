//
//  BANavigationController2.h
//  BABaseProject
//
//  Created by 博爱之家 on 16/6/11.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BANavigationController2 : UINavigationController

@end
