//
//  DemoVC10_ReusableView.h
//  BABaseProject
//
//  Created by 博爱 on 16/5/30.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DemoVC10_ReusableView : UICollectionReusableView

@property (nonatomic, strong) UILabel *titleLabel;


@end
