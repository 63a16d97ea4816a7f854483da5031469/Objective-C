//
//  BABaseModel.h
//  BABaseProject
//
//  Created by apple on 16/1/12.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "NSObject+BAParse.h"
//#import <MJExtension.h>

#import "NSObject+BAMJParse.h"

@interface BABaseModel : NSObject

@end
