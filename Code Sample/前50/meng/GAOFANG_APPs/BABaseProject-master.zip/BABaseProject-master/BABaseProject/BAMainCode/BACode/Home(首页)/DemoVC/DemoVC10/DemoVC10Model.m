//
//  DemoVC10Model.m
//  BABaseProject
//
//  Created by 博爱 on 16/5/30.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "DemoVC10Model.h"

@implementation DemoVC10Model

@end
