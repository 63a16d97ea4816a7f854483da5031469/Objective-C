//
//  BARotateView.h
//  BABaseProject
//
//  Created by 博爱 on 16/7/7.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BARotateAnimationProtocol.h"

@interface BARotateView : UIView <BARotateAnimationProtocol>

@end
