//
//  DemoVC2_01_cell.h
//  BABaseProject
//
//  Created by 博爱 on 16/7/6.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseCell.h"

typedef NS_ENUM(NSInteger, BAShowCellTextType) {
    BAShowCellTextTypeNormal,
    BAShowCellTextTypeExpend,
};

@interface DemoVC2_01_cell : BABaseCell

@end
