//
//  BACustomMJFooter.h
//  BABaseProject
//
//  Created by 博爱 on 16/7/11.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface BACustomMJFooter : MJRefreshAutoGifFooter

@end
