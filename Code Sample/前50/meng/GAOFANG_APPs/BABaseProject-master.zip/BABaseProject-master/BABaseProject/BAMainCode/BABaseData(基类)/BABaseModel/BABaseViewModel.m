//
//  BABaseViewModel.m
//  BABaseProject
//
//  Created by apple on 16/1/12.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "BABaseViewModel.h"

@implementation BABaseViewModel

@end
