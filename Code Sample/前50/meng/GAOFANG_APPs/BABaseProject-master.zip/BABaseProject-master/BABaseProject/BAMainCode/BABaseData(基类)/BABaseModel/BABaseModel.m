//
//  BABaseModel.m
//  BABaseProject
//
//  Created by apple on 16/1/12.
//  Copyright © 2016年 博爱之家. All rights reserved.
//

#import "BABaseModel.h"

@implementation BABaseModel

@end
