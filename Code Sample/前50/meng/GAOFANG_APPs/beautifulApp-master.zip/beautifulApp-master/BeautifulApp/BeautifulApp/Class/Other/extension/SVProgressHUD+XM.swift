
//
//  SVProgressHUD+XM.swift
//  baiduCourse
//
//  Created by 梁亦明 on 15/10/13.
//  Copyright © 2015年 xiaoming. All rights reserved.
//

import Foundation

//extension SVProgressHUD {
//    /**
//    *  显示toast :黑色框白色字风格
//    */
//    class func showMessage(message : String) {
//        SVProgressHUD.setBackgroundColor(UIColor.whiteColor())
//        SVProgressHUD.setForegroundColor(UIColor.darkGrayColor())
//        SVProgressHUD.showSuccessWithStatus(message)
//    }
//}