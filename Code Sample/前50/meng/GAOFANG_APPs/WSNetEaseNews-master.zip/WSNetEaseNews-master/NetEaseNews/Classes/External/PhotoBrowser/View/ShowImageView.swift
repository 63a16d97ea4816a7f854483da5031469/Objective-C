//
//  ShowImageView.swift
//  PhotoBrowser
//
//  Created by 冯成林 on 15/8/12.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

class ShowImageView: UIImageView {
    var showSize:CGSize!
}
