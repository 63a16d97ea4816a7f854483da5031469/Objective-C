//
//  YHCoderObject.h
//  YHCoder
//
//  Created by HaoYoson on 15/5/2.
//  Copyright (c) 2015年 www.hao.today. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YHCoderObject : NSObject

@end
