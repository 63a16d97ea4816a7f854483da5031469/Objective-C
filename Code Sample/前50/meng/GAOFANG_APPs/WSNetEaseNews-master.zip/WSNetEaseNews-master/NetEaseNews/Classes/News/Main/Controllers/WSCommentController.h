//
//  WSCommentController.h
//  网易新闻
//
//  Created by WackoSix on 16/1/1.
//  Copyright © 2016年 WackoSix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSCommentController : UIViewController

@property (copy, nonatomic) NSString *postid;

@property (copy, nonatomic) NSString *docid;

@end
