//
//  WSAudioController.h
//  网易新闻
//
//  Created by WackoSix on 16/1/11.
//  Copyright © 2016年 WackoSix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WSAudioController : UITableViewController


+(instancetype)audioController;

@end
