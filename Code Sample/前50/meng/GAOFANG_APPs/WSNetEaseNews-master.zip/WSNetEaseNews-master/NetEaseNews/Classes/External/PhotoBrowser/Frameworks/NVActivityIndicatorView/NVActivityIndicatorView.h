//
//  NVActivityIndicatorView.h
//  NVActivityIndicatorView
//
//  Created by MORITANAOKI on 2015/09/13.
//  Copyright (c) 2015年 Nguyen Vinh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for NVActivityIndicatorView.
FOUNDATION_EXPORT double NVActivityIndicatorViewVersionNumber;

//! Project version string for NVActivityIndicatorView.
FOUNDATION_EXPORT const unsigned char NVActivityIndicatorViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NVActivityIndicatorView/PublicHeader.h>


