//
//  NSString+WS.h
//  网易新闻
//
//  Created by WackoSix on 15/12/29.
//  Copyright © 2015年 WackoSix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (WS)

- (CGSize)sizeOfFont:(UIFont *)font textMaxSize:(CGSize)maxSize;

@end
