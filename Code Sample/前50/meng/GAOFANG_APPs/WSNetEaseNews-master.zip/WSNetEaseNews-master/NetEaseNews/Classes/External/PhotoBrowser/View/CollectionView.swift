//
//  PhotoBrowser+CollectionView.swift
//  PhotoBrowser
//
//  Created by 成林 on 15/7/29.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

import UIKit

extension PhotoBrowser{
    
    
    class CollectionView: UICollectionView {
    

    }
    
}


