//
//  MainController.h
//  WBZhiHuDailyPaper
//
//  Created by caowenbo on 15/12/18.
//  Copyright © 2015年 曹文博. All rights reserved.
//

#import <MMDrawerController/MMDrawerController.h>

@interface MainController : MMDrawerController

@property (nonatomic, strong) UINavigationController *naviController;

@end
