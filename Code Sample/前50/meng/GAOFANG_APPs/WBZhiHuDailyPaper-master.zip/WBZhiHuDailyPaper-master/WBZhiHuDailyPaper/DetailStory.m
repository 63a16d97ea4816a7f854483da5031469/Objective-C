//
//  DetailStory.m
//  WBZhiHuDailyPaper
//
//  Created by caowenbo on 15/12/20.
//  Copyright © 2015年 曹文博. All rights reserved.
//

#import "DetailStory.h"

@implementation DetailStory

@end
