//
//  ContainerController.h
//  WBZhiHuDailyPaper
//
//  Created by caowenbo on 15/12/24.
//  Copyright © 2015年 曹文博. All rights reserved.
//  内容页面的容器，实现上拉加载下一篇

#import <UIKit/UIKit.h>

@interface ContainerController : UIViewController

@property (nonatomic, strong) NSNumber *storyId;

@property (nonatomic, strong) id tool;


@end
