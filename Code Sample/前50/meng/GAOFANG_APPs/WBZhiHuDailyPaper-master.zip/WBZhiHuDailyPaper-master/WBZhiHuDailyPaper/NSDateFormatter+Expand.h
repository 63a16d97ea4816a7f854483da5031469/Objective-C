//
//  NSDateFormatter+Expand.h
//  WBZhiHuDailyPaper
//
//  Created by caowenbo on 15/12/24.
//  Copyright © 2015年 曹文博. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDateFormatter (Expand)

+ (instancetype)shareDateFormatter;

@end
