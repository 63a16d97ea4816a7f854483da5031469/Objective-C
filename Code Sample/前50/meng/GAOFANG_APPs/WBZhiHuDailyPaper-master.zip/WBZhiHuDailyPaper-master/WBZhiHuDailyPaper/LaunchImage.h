//
//  LaunchImage.h
//  WBZhiHuDailyPaper
//
//  Created by caowenbo on 15/12/18.
//  Copyright © 2015年 曹文博. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LaunchImage : NSObject

@property (nonatomic,copy) NSString *text;
@property (nonatomic,copy) NSString *img;

@end
