# 知乎日报（仿）
---
 首先感谢[izzyleung](https://github.com/izzyleung/ZhihuDailyPurify/wiki/知乎日报-API-分析)提供的API,该项目实现了知乎日报的基本功能，因为本人水平有限，可能会有些不足，还望各位大神能提供些意见。
 
 
#Demo Project
![demo1](http://7xpk2w.com1.z0.glb.clouddn.com/demo1.gif)

![demo2](http://7xpk2w.com1.z0.glb.clouddn.com/demo2.gif)

![demo3](http://7xpk2w.com1.z0.glb.clouddn.com/demo3.gif)

#已完成功能
* 启动动画的设置
* 文章的分类和展示
* 下拉刷新和上拉自动加载更
* 文章内部链接的webView和图片浏览器
* 3Dtouch的使用
* 上拉加载下一篇，下拉加载上一篇

##***如有问题或建议请通过邮件联系我***