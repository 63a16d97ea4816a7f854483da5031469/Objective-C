//
//  GTConfig.swift
//  GTMobile
//
//  Created by tung on 16/1/8.
//  Copyright © 2016年 GT. All rights reserved.
//

import Foundation

var GT_DEBUG_MODE = true

public let KAppKeyShareSDK   = "10054ace69d1f"

public let KAppIDWeiXin   = "wxa39cbd5e4182d317"

public let KAppSecretWeiXin   = "564120b02f3c15b60f559ac788079e24"
