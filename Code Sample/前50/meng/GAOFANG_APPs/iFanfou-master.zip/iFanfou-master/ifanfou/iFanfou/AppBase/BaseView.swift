//
//  BaseView.swift
//  GTMobile
//
//  Created by tung on 16/1/8.
//  Copyright © 2016年 GT. All rights reserved.
//

import UIKit

class BaseView: UIView {

    var gDict:AnyObject!{
        didSet {
            initCellView()
        }
    }
    
    func initCellView(){
        
    }

}
