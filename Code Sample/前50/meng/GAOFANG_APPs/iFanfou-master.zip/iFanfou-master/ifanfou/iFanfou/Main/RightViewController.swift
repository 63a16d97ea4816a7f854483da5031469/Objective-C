//
//  RightViewController.swift
//  GTMobile
//
//  Created by tung on 16/1/20.
//  Copyright © 2016年 GT. All rights reserved.
//

import UIKit

class RightViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.brownColor()
    }
}
