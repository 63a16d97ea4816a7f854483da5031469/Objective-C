//
//  UI
//DetailToolView.swift
//  GTMobile
//
//  Created by tung on 16/3/2.
//  Copyright © 2016年 GT. All rights reserved.
//

import UIKit

class UIDetailToolView: BaseView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
