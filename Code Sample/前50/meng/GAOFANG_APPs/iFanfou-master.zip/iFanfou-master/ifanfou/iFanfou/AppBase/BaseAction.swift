//
//  BaseAction.swift
//  GTMobile
//
//  Created by tung on 16/1/19.
//  Copyright © 2016年 GT. All rights reserved.
//

import Foundation

class BaseAction: NSObject {

}
