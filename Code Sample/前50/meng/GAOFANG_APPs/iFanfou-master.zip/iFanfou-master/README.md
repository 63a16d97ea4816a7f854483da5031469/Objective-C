# iFanfou
![app icon](https://github.com/GesanTung/iFanfou/blob/master/ifanfou/iFanfou/Assets.xcassets/AppIcon.appiconset/Icon-60%402x.png)
##swift 版 iOS 饭否客户端 源码

![app preview](https://github.com/GesanTung/iFanfou/blob/master/ifanfou/fanfou1gif.gif)

饭否是中国大陆地区第一家提供微博服务的网站，被称为中国版Twitter。用户可通过网页、WAP、手机短信/彩信、IM 软件（包括 QQ、MSN、GTalk）和上百种API 应用在自己的饭否页面上发布消息或上传图片。用户间通过互相关注、私信、或@对话等方式互动。自2009年7月7日起，该网站被关闭。2010年11月11日，饭否网页显示信息，11月25日晚饭否再度开放登入。发展至今，饭否是业界公认的微博鼻祖。饭否创始人王兴，人人网（原校内网）创始人，饭否网总裁，美团网创始人兼CEO。

饭否是目前国内类似网友的签名更新最快的一家站点。目前，已近有不少人开发了饭否的API（应用接口），其中一些非常有趣，像海内存知己，天涯共饭否、饭团、饭桌等。饭否除了能更新信息之外，还能通过图片来告诉你的朋友你在干什么。
饭否还是一个移动的网页收藏夹，你能通过在你的浏览器上加上API就能分享自己喜欢的网页。

本客户端根据饭否开放api接口开发，未全部完成开发，持续完善中，现将项目开源仅供学习交流

饭否api  <https://github.com/FanfouAPI/FanFouAPIDoc/wiki>

请大家前往饭否网注册账号或者登入我的测试账号
测试账号：tungleungs@gmail.com  密码：gesan

如有疑问联系 mail:tungleungs@gmail.com qq:603482184
