## 高仿爱鲜蜂 - Swift2.0
- 使用Swift2.0
- 编译器为Xcode7.0.1正式版,请用7.0以上的Xcode打开工程
- 直接打开xcworkspace运行工程即可
****

##项目效果图
![效果图1](http://ww3.sinaimg.cn/mw690/0068uRu1gw1f0n7ikeaxmg307u0dx7wp.gif)

![效果图2](http://ww1.sinaimg.cn/mw690/0068uRu1gw1f0n7ipld9dg307u0dx1l2.gif)

![效果图3](http://ww2.sinaimg.cn/mw690/0068uRu1gw1f0n7itiogog307u0dxnpg.gif)

![效果图4](http://ww1.sinaimg.cn/mw690/0068uRu1gw1f0n7ix5pbsg307u0dx7wk.gif)

![效果图5](http://ww3.sinaimg.cn/mw690/0068uRu1gw1f0n7iyf48gg307u0dxhdt.gif)

![效果图6](http://ww3.sinaimg.cn/mw690/0068uRu1gw1f0n7j1p2seg307u0dxx6q.gif)

![效果图7](http://ww4.sinaimg.cn/mw690/0068uRu1gw1f0n7j3szvmg307u0dxe81.gif)

![效果图8](http://ww3.sinaimg.cn/mw690/0068uRu1gw1f0n7j7eh6xg307u0dxx6s.gif)

![效果图9](http://ww3.sinaimg.cn/mw690/0068uRu1gw1f0n7jd82czg307u0dxkjp.gif)
****
**直接打开运行工程**![打开工作组运行工程](http://ww4.sinaimg.cn/mw690/0068uRu1gw1ewa9bfaipcj30au0c4t9p.jpg)
****
 ###文章链接
#### 小熊的技术博客
[点击链接我的博客](http://www.jianshu.com/users/5fe7513c7a57/latest_articles)

#### 小熊的新浪微博
[我的新浪微博](http://weibo.com/5622363113/profile?topnav=1&wvr=6)

#### 小熊的GitHub
[我的GitHub](https://github.com/ZhongTaoTian)