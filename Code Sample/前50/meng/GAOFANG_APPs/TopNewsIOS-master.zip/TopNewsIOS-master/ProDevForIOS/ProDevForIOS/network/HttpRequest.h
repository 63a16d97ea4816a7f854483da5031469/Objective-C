//
//  HttpRequest.h
//  ProDevForIOS
//
//  Created by 曹亚民 on 16/2/19.
//  Copyright © 2016年 曹亚民. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "HttpMethod.h"
#import "AppDelegate.h"
#import "Reachability.h"

@interface HttpRequest : NSObject

/*@property NSURLSessionDataTask *dataTask;
+ (HttpRequest *)sharedManager;
- (void)sendUrlByUrlSession:(HTTP_METHOD)type Url:(NSString *)neturl Paramters:(NSDictionary *)Parameters Success:(void(^)(NSData*))block Fail:(void(^)(NSString*))Nserror;
- (NSString *)serializeParams:(NSDictionary *)params;
- (NSString *)escapeValueForURLParameter:(NSString *)valueToEscape;*/
@end
