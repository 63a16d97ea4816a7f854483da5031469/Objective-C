//
//  Images.h
//  ProDevForIOS
//
//  Created by 曹亚民 on 16/3/15.
//  Copyright © 2016年 曹亚民. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageUrls : NSObject
@property (strong, nonatomic) NSString *article_id;
@property (strong, nonatomic) NSString *url;
@end
