//
//  Data.h
//  ProDevForIOS
//
//  Created by 曹亚民 on 16/2/20.
//  Copyright © 2016年 曹亚民. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Shop : NSObject
     @property (strong, nonatomic) NSString *acurl;
     @property (strong, nonatomic) NSArray *data;
@end
