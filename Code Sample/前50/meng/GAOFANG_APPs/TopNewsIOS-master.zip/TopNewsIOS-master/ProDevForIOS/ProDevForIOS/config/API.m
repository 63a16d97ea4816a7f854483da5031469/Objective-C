//
//  API.m
//  ProDevForIOS
//
//  Created by 曹亚民 on 16/3/15.
//  Copyright © 2016年 曹亚民. All rights reserved.
//

#import "API.h"
NSString * const ZIXUN_URL = @"api/news/app/lists/";
@implementation API

@end
