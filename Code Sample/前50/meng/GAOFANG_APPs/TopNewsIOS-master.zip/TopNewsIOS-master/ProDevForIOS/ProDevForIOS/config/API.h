//
//  API.h
//  ProDevForIOS
//
//  Created by 曹亚民 on 16/3/15.
//  Copyright © 2016年 曹亚民. All rights reserved.
//
/*POST请求api函数*/
#import <Foundation/Foundation.h>
extern NSString * const ZIXUN_URL;
@interface API : NSObject

@end
