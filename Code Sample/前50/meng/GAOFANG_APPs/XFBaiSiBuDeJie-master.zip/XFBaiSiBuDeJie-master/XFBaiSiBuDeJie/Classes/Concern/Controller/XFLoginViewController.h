//
//  XFLoginViewController.h
//  
//
//  Created by 谢飞 on 16/2/20.
//
//

#import <UIKit/UIKit.h>

@interface XFLoginViewController : UIViewController

@end
