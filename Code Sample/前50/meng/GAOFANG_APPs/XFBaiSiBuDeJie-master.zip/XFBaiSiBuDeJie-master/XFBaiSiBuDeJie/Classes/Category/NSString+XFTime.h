//
//  NSString+XFTime.h
//  XFBaiSiBuDeJie
//
//  Created by Fay on 16/3/15.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (XFTime)
+ (NSString *)stringWithTime:(NSTimeInterval)time;
@end
