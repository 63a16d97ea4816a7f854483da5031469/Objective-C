//
//  XFMainTableModel.m
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/2/19.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import "XFMainTableModel.h"

@implementation XFMainTableModel

//-(BOOL)isVip {
//    if ([self.is_vip isEqualToString:@"true"]) {
//        return YES;
//    }
//    return NO;
//}
@end
