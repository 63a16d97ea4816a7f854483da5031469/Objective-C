//
//  UIImageView+Header.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/3/3.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImageView (Header)
- (void)setHeader:(NSString *)url;
@end
