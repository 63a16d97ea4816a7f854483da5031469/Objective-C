//
//  XFGuideView.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/2/21.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFGuideView : UIView

+ (instancetype)guideView;

@end
