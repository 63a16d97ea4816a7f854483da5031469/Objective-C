//
//  XFUserModel.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/2/29.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XFUserModel : NSObject

@property (nonatomic, copy) NSString *username;
@property (nonatomic, copy) NSString *sex;
@property (nonatomic, copy) NSString *profile_image;

@end
