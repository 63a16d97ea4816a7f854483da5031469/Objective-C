//
//  XFMainTableCell.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/2/19.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XFMainTableModel.h"

@interface XFMainTableCell : UITableViewCell
@property (nonatomic, strong) XFMainTableModel *model;

@end
