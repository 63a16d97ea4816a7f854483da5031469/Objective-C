//
//  XFCommentCell.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/3/1.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XFCommentModel.h"

@interface XFCommentCell : UITableViewCell
@property (nonatomic, strong) XFCommentModel *comment;
@end
