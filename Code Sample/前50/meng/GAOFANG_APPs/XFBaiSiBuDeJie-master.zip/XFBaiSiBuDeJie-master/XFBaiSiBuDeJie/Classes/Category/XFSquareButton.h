//
//  XFSquareButton.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/3/4.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XFSquare.h"

@interface XFSquareButton : UIButton
@property (nonatomic,strong) XFSquare *square;
@end
