//
//  XFWebviewController.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/3/4.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XFWebviewController : UIViewController
@property (nonatomic, copy) NSString *url;
@end
