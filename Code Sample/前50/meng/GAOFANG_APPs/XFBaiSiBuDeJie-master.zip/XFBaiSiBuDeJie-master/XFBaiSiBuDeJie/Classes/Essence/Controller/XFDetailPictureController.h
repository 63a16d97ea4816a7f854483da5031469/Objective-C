//
//  XFDetailPictureController.h
//  XFBaiSiBuDeJie
//
//  Created by 谢飞 on 16/2/27.
//  Copyright © 2016年 谢飞. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XFTopicModel.h"

@interface XFDetailPictureController : UIViewController
@property (nonatomic,strong) XFTopicModel *topic;
@end
