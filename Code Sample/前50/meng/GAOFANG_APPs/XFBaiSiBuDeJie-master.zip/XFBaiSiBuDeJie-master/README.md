# XFBaiSiBuDeJie

####
高仿百思不得姐客户端

初次学习使用RAC，还不是怎么熟悉，使用的仍是MVC模式，MVVM还在摸索中...

如果大家觉得还不错，请给颗星星支持下~~~

## 程序中使用到的库
* `AFNetworking`
* `SDWebImage`
* `SVProgressHUD`
* `MJExtension`
* `ReactiveCocoa`
* `MJRefresh`
* `DACircularProgress`
* `NJKWebViewProgress`
* `KRVideoPlayerController`

## 完成的功能：

* 帖子的显示，包括，声音，视频，段子，图片
* 支持视频、音频的播放
* 登录页面的动画显示
* 帖子的评论显示
* 图片的放大显示
* 网页加载显示

-
![](http://7xoijj.com1.z0.glb.clouddn.com/baisi!!!.gif)

![](http://7xoijj.com1.z0.glb.clouddn.com/baisi%2001.png)
![](http://7xoijj.com1.z0.glb.clouddn.com/baisi%2002.png)

![](http://7xoijj.com1.z0.glb.clouddn.com/baisi%2003.png)
![](http://7xoijj.com1.z0.glb.clouddn.com/baidi%2004.png)

![](http://7xoijj.com1.z0.glb.clouddn.com/baisi%2005.png)
![](http://7xoijj.com1.z0.glb.clouddn.com/baisi%2006.png)



### 程序的还在完善中...如果有什么错误的地方欢迎大家指正，学习交流请Email:
[memoryoverflowing@foxmail.com]()