//
//  YLWNewsTableViewCell.h
//  推库iOS
//
//  Created by Mac on 16/2/18.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YLWArticleModel;
@interface YLWNewsTableViewCell : UITableViewCell
@property (nonatomic,strong) YLWArticleModel *articleModel;

@end
