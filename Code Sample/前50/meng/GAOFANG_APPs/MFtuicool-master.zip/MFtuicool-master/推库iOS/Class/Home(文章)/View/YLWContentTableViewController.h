
//
//  YLWContentTableViewController.h
//  推库iOS
//
//  Created by Mac on 16/2/18.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YLWContentTableViewController : UITableViewController

@property (nonatomic,copy) NSString *urlstring;

@property (nonatomic,copy) NSString *titlename;

@end
