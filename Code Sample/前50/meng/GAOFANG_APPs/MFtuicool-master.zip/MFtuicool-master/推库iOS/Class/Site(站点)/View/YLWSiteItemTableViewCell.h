//
//  YLWSiteItemTableViewCell.h
//  推库iOS
//
//  Created by Mac on 16/2/19.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import <UIKit/UIKit.h>
@class YLWSiteItemModel;
@interface YLWSiteItemTableViewCell : UITableViewCell

@property (nonatomic,strong) YLWSiteItemModel *siteItemModel;

@end
