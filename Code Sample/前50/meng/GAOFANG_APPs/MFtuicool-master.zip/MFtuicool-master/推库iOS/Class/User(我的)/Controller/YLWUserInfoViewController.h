//
//  YLWUserInfoViewController.h
//  推库iOS
//
//  Created by Mac on 16/2/22.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YLWUserInfoViewController : UITableViewController

@end
