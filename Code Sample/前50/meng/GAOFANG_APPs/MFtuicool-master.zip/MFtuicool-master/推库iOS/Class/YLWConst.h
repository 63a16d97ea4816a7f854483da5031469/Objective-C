//
//  YLWConst.h
//  推库iOS
//
//  Created by Mac on 16/2/23.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import <Foundation/Foundation.h>

//没有加引用extern 出现bug
extern  NSString *const YLWPushToDetailTextVCNotification;
extern  NSString *const YLWDetailTextIdKeyd;
