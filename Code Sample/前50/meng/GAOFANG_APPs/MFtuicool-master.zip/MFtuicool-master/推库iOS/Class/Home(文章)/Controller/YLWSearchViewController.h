//
//  YLWSearchViewController.h
//  推库iOS
//
//  Created by Mac on 16/3/3.
//  Copyright © 2016年 YLW. All rights reserved.
//

#import "YLWBasesHomeViewController.h"

@interface YLWSearchViewController : YLWBasesHomeViewController


@end
