//
//  oc.h
//  CoreJPush
//
//  Created by 冯成林 on 16/1/28.
//  Copyright © 2016年 冯成林. All rights reserved.
//

#ifndef oc_h
#define oc_h

#import "CoreJPush.h"

#endif /* oc_h */
