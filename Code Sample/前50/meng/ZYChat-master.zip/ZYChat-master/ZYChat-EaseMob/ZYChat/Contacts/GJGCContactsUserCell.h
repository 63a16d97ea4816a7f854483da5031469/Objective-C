//
//  GJGCContactsUserCell.h
//  ZYChat
//
//  Created by ZYVincent on 16/8/9.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import "GJGCContactsBaseCell.h"

@interface GJGCContactsUserCell : GJGCContactsBaseCell

@end
