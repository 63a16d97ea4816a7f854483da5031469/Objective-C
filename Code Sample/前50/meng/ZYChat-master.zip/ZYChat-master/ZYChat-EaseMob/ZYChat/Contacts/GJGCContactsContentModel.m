//
//  GJGCContactsContentModel.m
//  ZYChat
//
//  Created by ZYVincent on 16/8/8.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import "GJGCContactsContentModel.h"

@implementation GJGCContactsContentModel

@end
