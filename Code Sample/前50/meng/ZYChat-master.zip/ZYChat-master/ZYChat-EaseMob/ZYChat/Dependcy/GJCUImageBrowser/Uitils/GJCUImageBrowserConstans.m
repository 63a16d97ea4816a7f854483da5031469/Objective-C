//
//  GJCFImageBrowserConstans.m
//  GJCommonFoundation
//
//  Created by ZYVincent QQ:1003081775 on 14-10-30.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJCUImageBrowserConstans.h"

NSString *const GJCUImageBrowserItemViewControllerDidTapNoti = @"GJCFImageBrowserItemViewControllerDidTapNoti";

NSString *const GJCUImageBrowserViewControllerDidBeginDownloadTaskNoti = @"GJCFImageBrowserViewControllerDidBeginDownloadTaskNoti";

NSString *const GJCUImageBrowserViewControllerDidFinishDownloadTaskNoti = @"GJCFImageBrowserViewControllerDidFinishDownloadTaskNoti";

NSString *const GJCUImageBrowserViewControllerDidFaildDownloadTaskNoti = @"GJCFImageBrowserViewControllerDidFaildDownloadTaskNoti";

@implementation GJCUImageBrowserConstans

@end
