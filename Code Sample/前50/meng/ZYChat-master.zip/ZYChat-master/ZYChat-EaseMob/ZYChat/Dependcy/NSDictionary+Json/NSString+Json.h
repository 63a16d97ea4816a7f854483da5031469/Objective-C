//
//  NSString+Json.h
//  ZYChat
//
//  Created by ZYVincent on 16/6/29.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Json)

- (NSDictionary *)toDictionary;

@end
