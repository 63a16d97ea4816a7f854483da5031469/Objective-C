//
//  GJGCSystemNotiViewController.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-11-11.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatDetailViewController.h"
#import "GJGCChatSystemNotiDataManager.h"

@interface GJGCChatSystemNotiViewController : GJGCChatDetailViewController

@end
