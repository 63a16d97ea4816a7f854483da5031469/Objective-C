//
//  GJGCChatFriendWebPageCell.h
//  ZYChat
//
//  Created by ZYVincent on 15/11/24.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import "GJGCChatFriendBaseCell.h"

@interface GJGCChatFriendWebPageCell : GJGCChatFriendBaseCell

@end
