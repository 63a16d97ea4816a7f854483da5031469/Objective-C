//
//  GJGCMessageExtendMiniMessageModel.h
//  ZYChat
//
//  Created by ZYVincent on 16/6/29.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import "JSONModel.h"

@interface GJGCMessageExtendMiniMessageModel : JSONModel

@property (nonatomic,strong)NSString *displayText;

@property (nonatomic,strong)NSString *notSupportDisplayText;

@end
