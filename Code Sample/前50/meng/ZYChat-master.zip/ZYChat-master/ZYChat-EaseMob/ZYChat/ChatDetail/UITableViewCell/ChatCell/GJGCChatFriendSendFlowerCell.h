//
//  GJGCChatFriendSendFlowerCell.h
//  ZYChat
//
//  Created by ZYVincent on 16/5/15.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import "GJGCChatFriendBaseCell.h"

@interface GJGCChatFriendSendFlowerCell : GJGCChatFriendBaseCell

@end
