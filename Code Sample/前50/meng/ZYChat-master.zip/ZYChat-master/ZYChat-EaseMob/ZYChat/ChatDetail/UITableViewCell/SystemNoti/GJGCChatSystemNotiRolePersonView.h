//
//  GJGCChatSystemNotiRolePersonView.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-11-3.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GJGCChatSystemNotiRolePersonView : UIView

@property (nonatomic,assign)NSInteger sex;

@property (nonatomic,strong)NSAttributedString *age;

@property (nonatomic,strong)NSAttributedString *starName;


@end
