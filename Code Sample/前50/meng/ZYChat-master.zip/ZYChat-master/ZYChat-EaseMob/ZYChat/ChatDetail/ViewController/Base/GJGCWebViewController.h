//
//  GJGCWebViewController.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 15/7/11.
//  Copyright (c) 2015年 ZYProSoft.  QQ群:219357847  All rights reserved.
//

#import "GJGCBaseViewController.h"

@interface GJGCWebViewController : GJGCBaseViewController

- (instancetype)initWithUrl:(NSString *)url;

- (void)setUrl:(NSString *)url;

@end
