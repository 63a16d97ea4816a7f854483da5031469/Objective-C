//
//  GJGCMessageExtendGroupModel.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 15/11/22.
//  Copyright (c) 2015年 ZYProSoft.  QQ群:219357847  All rights reserved.
//

#import "JSONModel.h"

@interface GJGCMessageExtendGroupModel : JSONModel

@property (nonatomic,strong)NSString *groupHeadThumb;

@property (nonatomic,strong)NSString *groupName;


@end
