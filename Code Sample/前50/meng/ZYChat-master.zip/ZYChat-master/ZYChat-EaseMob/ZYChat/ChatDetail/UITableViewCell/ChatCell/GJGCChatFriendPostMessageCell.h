//
//  GJGCChatFriendPostMessageCell.h
//  ZYChat
//
//  Created by ZYVincent QQ:1003081775 on 14-12-11.
//  Copyright (c) 2014年 ZYProSoft. All rights reserved.
//

#import "GJGCChatFriendImageMessageCell.h"

@interface GJGCChatFriendPostMessageCell : GJGCChatFriendImageMessageCell


@end
