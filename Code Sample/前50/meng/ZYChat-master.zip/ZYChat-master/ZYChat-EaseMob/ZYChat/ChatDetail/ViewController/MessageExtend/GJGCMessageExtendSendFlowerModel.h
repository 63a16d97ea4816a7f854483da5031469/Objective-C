//
//  GJGCMessageExtendSendFlower.h
//  ZYChat
//
//  Created by ZYVincent on 16/5/15.
//  Copyright © 2016年 ZYProSoft. All rights reserved.
//

#import "JSONModel.h"

@interface GJGCMessageExtendSendFlowerModel : JSONModel

@property (nonatomic,strong)NSString *displayText;

@property (nonatomic,strong)NSString *notSupportDisplayText;

@property (nonatomic,strong)NSString *title;

@end
