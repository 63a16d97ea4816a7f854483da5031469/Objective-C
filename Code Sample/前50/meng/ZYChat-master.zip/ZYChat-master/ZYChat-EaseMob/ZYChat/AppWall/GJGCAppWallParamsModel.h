//
//  GJGCAppWallParamsModel.h
//  ZYChat
//
//  Created by ZYVincent on 15/11/26.
//  Copyright (c) 2015年 ZYProSoft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GJGCAppWallParamsModel : NSObject

@property (nonatomic,assign)BOOL isPay;

@property (nonatomic,strong)NSString *categoryId;

@property (nonatomic,strong)NSString *area;

@property (nonatomic,strong)NSString *date;

@property (nonatomic,strong)NSString *device;

@end
