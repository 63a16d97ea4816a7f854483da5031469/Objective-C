//
//  City.h
//  CoreModel
//
//  Created by 冯成林 on 15/9/9.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "CoreModel.h"

@interface City : CoreModel

@property (nonatomic,copy) NSString *cityName;

@property (nonatomic,copy) NSString *spell;

@end
