//
//  Test2VC.m
//  CoreModel
//
//  Created by 冯成林 on 15/9/9.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import "Test2VC.h"


@interface Test2VC ()

@end

@implementation Test2VC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    /** 全自动创表 */
    Person *person = [[Person alloc] init];
    
}



@end
