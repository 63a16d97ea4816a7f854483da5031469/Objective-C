//
//  Test17VC.h
//  CoreModel
//
//  Created by 冯成林 on 16/4/3.
//  Copyright © 2016年 冯成林. All rights reserved.
//

#import "Test2VC.h"

@interface Test17VC : Test2VC

@end
