//
//  NSString+CoreFMDB.h
//  CoreFMDB
//
//  Created by muxi on 15/3/27.
//  Copyright (c) 2015年 muxi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CoreFMDB)



/**
 *  转为documents下的子文件夹
 */
@property (nonatomic,copy,readonly) NSString *documentsSubFolder;











@end
