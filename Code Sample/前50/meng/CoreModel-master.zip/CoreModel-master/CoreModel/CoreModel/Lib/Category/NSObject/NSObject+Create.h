//
//  NSObject+Create.h
//  CoreModel
//
//  Created by muxi on 15/3/30.
//  Copyright (c) 2015年 muxi. All rights reserved.
//  创表

#import <Foundation/Foundation.h>

@interface NSObject (Create)


+(void)tableCreate;



@end
