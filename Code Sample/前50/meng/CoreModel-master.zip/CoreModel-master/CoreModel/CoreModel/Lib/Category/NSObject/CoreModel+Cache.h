//
//  NSObject+Cache.h
//  CoreModel
//
//  Created by 冯成林 on 15/9/10.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CoreModel.h"
#import "CoreModelType.h"

@interface CoreModel (Cache)

@end
