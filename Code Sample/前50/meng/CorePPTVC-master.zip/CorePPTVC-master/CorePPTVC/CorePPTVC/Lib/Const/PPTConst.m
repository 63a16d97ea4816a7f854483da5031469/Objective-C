//
//  PPTConst.m
//  CorePPTVC
//
//  Created by 冯成林 on 15/4/30.
//  Copyright (c) 2015年 冯成林. All rights reserved.
//

#ifndef _PPTConst_M_
#define _PPTConst_M_

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


/** 总组数 */
NSUInteger const PPTsectionCount = 20;


/** 是否开启transition动画 */
BOOL const isUseTransitionAnim = YES;

/** 动画时长 */
CGFloat const PPTAnimTime = 3.6;
















#endif
