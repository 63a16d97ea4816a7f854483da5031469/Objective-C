//
//  iLinkMacAppDelegate.h
//  iLinkMac
//
//  Created by Idan S on 11/01/2014.
//  Copyright 2014 Idan S
//

#import <Cocoa/Cocoa.h>

@interface iLinkMacAppDelegate : NSObject <NSApplicationDelegate>

@property (unsafe_unretained) IBOutlet NSWindow *window;

@end
