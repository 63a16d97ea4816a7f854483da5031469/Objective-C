//
//  main.m
//  iLinkMac
//
//  Created by Idan S on 11/01/2014.
//  Copyright 2014 Idan S
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, nil);
    //return NSApplicationMain(argc,  (const char **) argv);
}
