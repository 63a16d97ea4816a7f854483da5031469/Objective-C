//
//  main.m
//  iRate
//
//  Created by Idan S on 11/01/2014.
//  Copyright 2014 Idan S
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    @autoreleasepool {
        int retVal = UIApplicationMain(argc, argv, nil, nil);
        return retVal;
    }
}
