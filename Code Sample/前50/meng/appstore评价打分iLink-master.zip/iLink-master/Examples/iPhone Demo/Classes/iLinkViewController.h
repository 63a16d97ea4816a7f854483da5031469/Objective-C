//
//  iLinkViewController.h
//  iLink
//
//  Created by Idan S on 11/01/2014.
//  Copyright 2014 Idan S
//

#import <UIKit/UIKit.h>

@interface iLinkViewController : UIViewController

@end

