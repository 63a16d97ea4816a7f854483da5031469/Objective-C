//
//  FormattersViewController.h
//  XLForm
//
//  Created by Freddy Henin on 12/29/14.
//  Copyright (c) 2014 Xmartlabs. All rights reserved.
//

#import "XLFormViewController.h"

@interface FormattersViewController : XLFormViewController

@end
