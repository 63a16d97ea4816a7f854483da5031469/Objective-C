//
//  BFKit.h
//  BFKit
//
//  Created by Fabrizio on 07/11/15.
//  Copyright © 2015 Fabrizio Brancati. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BFKit.
FOUNDATION_EXPORT double BFKitVersionNumber;

//! Project version string for BFKit.
FOUNDATION_EXPORT const unsigned char BFKitVersionString[];

#import <BFKit/BFKit.h>
