//
//  InfoViewController.h
//  BFKitDemo
//
//  Created by Fabrizio on 15/11/14.
//  Copyright (c) 2014 Fabrizio Brancati. All rights reserved.
//

@import UIKit;

@interface InfoViewController : UIViewController

@end
