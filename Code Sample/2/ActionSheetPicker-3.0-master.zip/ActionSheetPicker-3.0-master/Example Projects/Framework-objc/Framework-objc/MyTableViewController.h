//
//  MyTableViewController.h
//  Framework-objc
//
//  Created by Petr Korolev on 14/04/15.
//  Copyright (c) 2015 Petr Korolev. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTableViewController : UITableViewController

@end
