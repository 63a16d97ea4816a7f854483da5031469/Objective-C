//
//  ActivityIndicatorCollectionReusableView.m
//  ios-admin-application
//
//  Created by Michail Grebionkin on 25.09.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "ActivityIndicatorCollectionReusableView.h"

@implementation ActivityIndicatorCollectionReusableView

- (void)awakeFromNib {
    // Initialization code
}

@end
