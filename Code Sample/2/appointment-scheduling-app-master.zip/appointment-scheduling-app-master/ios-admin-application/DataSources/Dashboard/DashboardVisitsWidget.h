//
//  DashboardVisitsWidget.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 25.09.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "DashboardAbstractWidgetDataSource.h"

@interface DashboardVisitsWidget : DashboardAbstractWidgetDataSource

@end
