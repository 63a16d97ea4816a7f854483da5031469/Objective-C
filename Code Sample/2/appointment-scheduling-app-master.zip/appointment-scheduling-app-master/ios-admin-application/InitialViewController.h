//
//  ViewController.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 18.08.15.
//  Copyright (c) 2015 Michail Grebionkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InitialViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIImageView *loginLogoImageView;
@property (nonatomic, weak) IBOutlet UILabel *loginLabel;

@end

