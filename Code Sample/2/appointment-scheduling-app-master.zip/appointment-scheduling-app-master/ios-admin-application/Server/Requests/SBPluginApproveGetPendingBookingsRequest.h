//
//  SBPluginApproveGetPendingBookingsRequest.h
//  ios-admin-application
//
//  Created by Michail Grebionkin on 16.11.15.
//  Copyright © 2015 Michail Grebionkin. All rights reserved.
//

#import "SBRequestOperation.h"

/// @see http://wiki.simplybook.me/index.php/Plugins#Approve_booking
@interface SBPluginApproveGetPendingBookingsRequest : SBRequestOperation

@end
