//
//  JVFloatLabeledTextFieldXIBViewController.h
//  JVFloatLabeledTextField
//
//  Created by Jared Verdi on 4/2/16.
//  Copyright © 2016 Jared Verdi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JVFloatLabeledTextFieldXIBViewController : UIViewController

@end
