//
//  PageViewController.h
//  MMParallaxScrollPresenter
//
//  Created by Malleo, Mitch on 12/19/14.
//

#import <UIKit/UIKit.h>

@interface PageViewController : UIViewController

@end
