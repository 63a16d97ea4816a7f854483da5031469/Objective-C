//
//  EasyTipView.h
//  EasyTipView
//
//  Created by Teodor Patras on 11/06/16.
//  Copyright © 2016 teodorpatras. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for EasyTipView.
FOUNDATION_EXPORT double EasyTipViewVersionNumber;

//! Project version string for EasyTipView.
FOUNDATION_EXPORT const unsigned char EasyTipViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <EasyTipView/PublicHeader.h>


