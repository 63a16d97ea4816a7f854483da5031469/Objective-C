//
//  MainViewController.h
//  MMScrollPresenter
//
//  Created by Malleo, Mitch on 10/31/14.
//

#import <UIKit/UIKit.h>
#import "MMScrollPresenter.h"
#import "MMScrollPage.h"

@interface MainViewController : UIViewController

@end
