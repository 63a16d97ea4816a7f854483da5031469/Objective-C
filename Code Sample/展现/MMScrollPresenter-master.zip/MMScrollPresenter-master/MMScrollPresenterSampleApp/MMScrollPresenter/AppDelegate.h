//
//  AppDelegate.h
//  MMScrollPresenter
//
//  Created by Malleo, Mitch on 10/31/14.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UIViewController *viewController;


@end

