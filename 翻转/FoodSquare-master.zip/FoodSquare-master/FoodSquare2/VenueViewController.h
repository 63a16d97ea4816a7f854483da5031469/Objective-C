//
//  VenueViewController.h
//  FoodSquare2
//
//  Created by Natasha Murashev on 5/23/13.
//  Copyright (c) 2013 Natasha Murashev. All rights reserved.
//

#import "VenuesListViewController.h"
#import "Venue.h"

@interface VenueViewController : VenuesListViewController

@property (strong, nonatomic) Venue *venue;

@end
