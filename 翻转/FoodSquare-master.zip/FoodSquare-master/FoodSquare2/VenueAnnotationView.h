//
//  VenueAnnotationView.h
//  FoodSquare2
//
//  Created by Natasha Murashev on 5/26/13.
//  Copyright (c) 2013 Natasha Murashev. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface VenueAnnotationView : MKAnnotationView

@end
