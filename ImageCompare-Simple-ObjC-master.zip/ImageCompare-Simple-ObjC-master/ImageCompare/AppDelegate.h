//
//  AppDelegate.h
//  ImageCompare
//
//  Created by Felipe Laso Marsetti on 4/29/15.
//  Copyright (c) 2015 Felipe Laso-Marsetti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

