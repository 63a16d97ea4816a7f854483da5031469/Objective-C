//
//  ViewController.m
//  ImageCompare
//
//  Created by Felipe Laso Marsetti on 4/29/15.
//  Copyright (c) 2015 Felipe Laso-Marsetti. All rights reserved.
//

#import <CommonCrypto/CommonDigest.h>
#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

#pragma mark - Private Methods

- (void)compareImages
{
    UIImage *image = [UIImage imageNamed:@"Image"];
    UIImage *image2 = [UIImage imageNamed:@"Image2"];
    UIImage *minorDiff = [UIImage imageNamed:@"MinorDiff"];
    UIImage *otherImage = [UIImage imageNamed:@"OtherImage"];
    
    NSLog(@"\tEQUAL IMAGE CHECKER");
    NSLog(@"Image 1\tImage 2\t\t\tMethod\t\t\t\t\t\t\tTime\t\tEqual Images?");
    
    //
    // areHashesPngEqualForImage:andImage:
    //
    
    // Comparing Same Images
    NSDate *startDate = [NSDate date];
    BOOL equalImages = [self areHashesPngEqualForImage:image andImage:image2];
    NSDate *endDate = [NSDate date];
    NSTimeInterval executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tIMAGE2\t\t\tareHashesPngEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing images with minor differences
    startDate = [NSDate date];
    equalImages = [self areHashesPngEqualForImage:image andImage:minorDiff];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tMINOR DIFF\t\tareHashesPngEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing two different images
    startDate = [NSDate date];
    equalImages = [self areHashesPngEqualForImage:image andImage:otherImage];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tOTHER IMAGE\t\tareHashesPngEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    //
    // areHashesJpegEqualForImage:andImage:quality:
    //
    NSLog(@"\n");
    
    // Comparing Same Images
    startDate = [NSDate date];
    equalImages = [self areHashesJpegEqualForImage:image andImage:image2 quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tIMAGE2\t\t\tareHashesJpegEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing images with minor differences
    startDate = [NSDate date];
    equalImages = [self areHashesJpegEqualForImage:image andImage:minorDiff quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tMINOR DIFF\t\tareHashesJpegEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing two different images
    startDate = [NSDate date];
    equalImages = [self areHashesJpegEqualForImage:image andImage:otherImage quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tOTHER IMAGE\t\tareHashesJpegEqualForImage\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    //
    // arePngEqualForImage:andImage:
    //
    NSLog(@"\n");
    
    // Comparing Same Images
    startDate = [NSDate date];
    equalImages = [self arePngEqualForImage:image andImage:image2];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tIMAGE2\t\t\tarePngEqualForImage\t\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing images with minor differences
    startDate = [NSDate date];
    equalImages = [self arePngEqualForImage:image andImage:minorDiff];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tMINOR DIFF\t\tarePngEqualForImage\t\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing two different images
    startDate = [NSDate date];
    equalImages = [self arePngEqualForImage:image andImage:otherImage];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tOTHER IMAGE\t\tarePngEqualForImage\t\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    //
    // areJpegEqualForImage
    //
    NSLog(@"\n");
    
    // Comparing Same Images
    startDate = [NSDate date];
    equalImages = [self areJpegEqualForImage:image andImage:image2 quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tIMAGE2\t\t\tareJpegEqualForImage\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing images with minor differences
    startDate = [NSDate date];
    equalImages = [self areJpegEqualForImage:image andImage:minorDiff quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tMINOR DIFF\t\tareJpegEqualForImage\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing two different images
    startDate = [NSDate date];
    equalImages = [self areJpegEqualForImage:image andImage:otherImage quality:0.1];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tOTHER IMAGE\t\tareJpegEqualForImage\t\t\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    //
    // isImage:apparentlyEqualToImage:
    //
    NSLog(@"\n");
    
    // Comparing Same Images
    startDate = [NSDate date];
    equalImages = [self isImage:image apparentlyEqualToImage:image2 accordingToRandomPixelsPer1:0.000001];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tIMAGE2\t\t\tisImage:apparentlyEqualToImage:\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing images with minor differences
    startDate = [NSDate date];
    equalImages = [self isImage:image apparentlyEqualToImage:minorDiff accordingToRandomPixelsPer1:0.000001];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tMINOR DIFF\t\tisImage:apparentlyEqualToImage:\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
    
    // Comparing two different images
    startDate = [NSDate date];
    equalImages = [self isImage:image apparentlyEqualToImage:otherImage accordingToRandomPixelsPer1:0.000001];
    endDate = [NSDate date];
    executionTime = [endDate timeIntervalSinceDate:startDate];
    NSLog(@"IMAGE\tOTHER IMAGE\t\tisImage:apparentlyEqualToImage:\t%f\t%@", executionTime, equalImages ? @"YES" : @"NO");
}

#pragma mark - Data Methods

- (BOOL)arePngEqualForImage:(UIImage *)imageA andImage:(UIImage *)imageB
{
    NSData *imageAData = UIImagePNGRepresentation(imageA);
    NSData *imageBData = UIImagePNGRepresentation(imageB);
    
    return [imageAData isEqualToData:imageBData];
}

- (BOOL)areJpegEqualForImage:(UIImage *)imageA andImage:(UIImage *)imageB quality:(CGFloat)quality
{
    NSData *imageAData = UIImageJPEGRepresentation(imageA, quality);
    NSData *imageBData = UIImageJPEGRepresentation(imageB, quality);
    
    return [imageAData isEqualToData:imageBData];
}

#pragma mark - Hashing Methods

- (BOOL)areHashesPngEqualForImage:(UIImage *)imageA andImage:(UIImage *)imageB
{
    NSString *imageAHash = [self md5HashPngForImage:imageA];
    NSString *imageBHash = [self md5HashPngForImage:imageB];
    
    return [imageAHash isEqualToString:imageBHash];
}

- (BOOL)areHashesJpegEqualForImage:(UIImage *)imageA andImage:(UIImage *)imageB quality:(CGFloat)quality
{
    NSString *imageAHash = [self md5HashJpegForImage:imageA compressionQuality:quality];
    NSString *imageBHash = [self md5HashJpegForImage:imageB compressionQuality:quality];
    
    return [imageAHash isEqualToString:imageBHash];
}

- (NSString *)md5HashPngForImage:(UIImage *)image
{
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    
    NSData *imageData = UIImagePNGRepresentation(image);
    
    CC_MD5([imageData bytes], (CC_LONG)[imageData length], result);
    
    NSString *imageHash = [NSString stringWithFormat:
                           @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
                           result[0], result[1], result[2], result[3],
                           result[4], result[5], result[6], result[7],
                           result[8], result[9], result[10], result[11],
                           result[12], result[13], result[14], result[15]
                           ];
    
    return imageHash;
}

- (NSString *)md5HashJpegForImage:(UIImage *)image compressionQuality:(CGFloat)quality
{
    unsigned char result[CC_MD5_DIGEST_LENGTH];
    
    NSData *imageData = UIImageJPEGRepresentation(image, quality);
    
    CC_MD5([imageData bytes], (CC_LONG)[imageData length], result);
    
    NSString *imageHash = [NSString stringWithFormat:
                           @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
                           result[0], result[1], result[2], result[3],
                           result[4], result[5], result[6], result[7],
                           result[8], result[9], result[10], result[11],
                           result[12], result[13], result[14], result[15]
                           ];
    
    return imageHash;
}

#pragma mark - Pixel Methods

- (BOOL)isImage:(UIImage *)imageA apparentlyEqualToImage:(UIImage *)imageB accordingToRandomPixelsPer1:(float)pixelsPer1
{
    size_t pixelsWidth = CGImageGetWidth(imageA.CGImage);
    size_t pixelsHeight = CGImageGetHeight(imageA.CGImage);
    
    int pixelsToCompare = pixelsWidth * pixelsHeight * pixelsPer1;
    
    uint32_t pixel1;
    CGContextRef context1 = CGBitmapContextCreate(&pixel1, 1, 1, 8, 4, CGColorSpaceCreateDeviceRGB(), 6);
    uint32_t pixel2;
    CGContextRef context2 = CGBitmapContextCreate(&pixel2, 1, 1, 8, 4, CGColorSpaceCreateDeviceRGB(), 6);
    
    BOOL isEqual = YES;
    
    for (int i = 0; i < pixelsToCompare; i++)
    {
        int pixelX = arc4random() % pixelsWidth;
        int pixelY = arc4random() % pixelsHeight;
        
        CGContextDrawImage(context1, CGRectMake(-pixelX, -pixelY, pixelsWidth, pixelsHeight), imageA.CGImage);
        CGContextDrawImage(context2, CGRectMake(-pixelX, -pixelY, pixelsWidth, pixelsHeight), imageB.CGImage);
        
        if (pixel1 != pixel2)
        {
            isEqual = NO;
            break;
        }
    }
    
    CGContextRelease(context1);
    CGContextRelease(context2);
    
    return isEqual;
}

#pragma mark - View Controller

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self compareImages];
}

@end
