# Simple Image Compare In Objective-C

A simple Objective-C iOS project to compare two images at a pixel level. 
