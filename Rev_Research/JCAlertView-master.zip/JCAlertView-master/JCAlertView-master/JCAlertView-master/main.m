//
//  main.m
//  JCAlertView-master
//
//  Created by mac on 15/10/30.
//  Copyright © 2015年 HJaycee. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
