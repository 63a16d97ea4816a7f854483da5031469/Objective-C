//
//  AppDelegate.h
//  JCAlertView-master
//
//  Created by mac on 15/10/30.
//  Copyright © 2015年 HJaycee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

