//
//  SecondViewController.h
//  PopupDemo
//
//  Created by chintan on 26/04/13.
//  Copyright (c) 2013 ZWT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *dismisclick;
- (IBAction)dismicclick:(id)sender;
@end
