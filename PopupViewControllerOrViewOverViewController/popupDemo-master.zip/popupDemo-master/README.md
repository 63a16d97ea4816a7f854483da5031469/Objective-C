popupDemo
=========

This is an iOS demo app to show UIViewController as popup

Sometime we require to show a small form with jus 2 3 input field.

For that we prefer to show UIViewController Modely.

Here I show a demo How can we show UIViewController Modely so it look like popup.

To know detail visit this link : http://stackoverflow.com/questions/16230700/display-uiviewcontroller-as-popup-in-iphone/16230701#16230701

A very nice job on this concept : https://github.com/m1entus/MZFormSheetController
