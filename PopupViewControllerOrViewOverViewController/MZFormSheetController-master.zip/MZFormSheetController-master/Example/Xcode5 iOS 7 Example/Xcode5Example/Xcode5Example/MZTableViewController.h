//
//  MZTableViewController.h
//  Xcode5Example
//
//  Created by Michał Zaborowski on 03.01.2014.
//  Copyright (c) 2014 Michał Zaborowski. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MZTableViewController : UITableViewController
@property (weak, nonatomic) IBOutlet UITextField *textField;

@end
