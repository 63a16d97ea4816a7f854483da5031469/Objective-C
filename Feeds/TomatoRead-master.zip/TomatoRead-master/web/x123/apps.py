from django.apps import AppConfig


class X123Config(AppConfig):
    name = 'x123'
