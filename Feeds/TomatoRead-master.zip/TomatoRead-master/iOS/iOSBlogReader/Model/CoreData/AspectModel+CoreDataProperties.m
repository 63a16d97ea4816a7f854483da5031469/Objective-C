//
//  AspectModel+CoreDataProperties.m
//  iOSBlogReader
//
//  Created by everettjf on 16/5/14.
//  Copyright © 2016年 everettjf. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AspectModel+CoreDataProperties.h"

@implementation AspectModel (CoreDataProperties)

@dynamic name;
@dynamic oid;
@dynamic zindex;
@dynamic domain;

@end
