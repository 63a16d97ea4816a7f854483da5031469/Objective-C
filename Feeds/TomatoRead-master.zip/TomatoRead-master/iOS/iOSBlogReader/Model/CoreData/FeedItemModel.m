//
//  FeedItemModel.m
//  iOSBlogReader
//
//  Created by everettjf on 16/4/11.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "FeedItemModel.h"

@implementation FeedItemModel

// Insert code here to add functionality to your managed object subclass

@end
