//
//  FeedModel.m
//  iOSBlogReader
//
//  Created by everettjf on 16/4/9.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "FeedModel.h"

@implementation FeedModel

// Insert code here to add functionality to your managed object subclass

@end
