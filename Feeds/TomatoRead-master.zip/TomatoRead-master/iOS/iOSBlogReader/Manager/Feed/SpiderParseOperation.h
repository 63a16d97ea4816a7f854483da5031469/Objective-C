//
//  SpiderParseOperation.h
//  iOSBlogReader
//
//  Created by everettjf on 16/5/9.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "ParseOperationBase.h"


@interface SpiderParseOperation : ParseOperationBase

@end
