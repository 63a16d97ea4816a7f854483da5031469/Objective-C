//
//  AboutViewController.h
//  iOSBlogReader
//
//  Created by everettjf on 16/5/11.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "EEViewController.h"

@interface AboutViewController : EEViewController

@end
