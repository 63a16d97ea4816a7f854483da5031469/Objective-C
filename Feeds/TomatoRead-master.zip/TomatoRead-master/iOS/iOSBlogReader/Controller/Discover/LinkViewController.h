//
//  LinkViewController.h
//  iOSBlogReader
//
//  Created by everettjf on 16/4/6.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PageDataset.h"
#import "EEViewController.h"

@interface LinkViewController : EEViewController
@property (strong,nonatomic) PageItemEntity *item;

@end
