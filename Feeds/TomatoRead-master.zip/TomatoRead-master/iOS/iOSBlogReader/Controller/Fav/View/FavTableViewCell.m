//
//  FavTableViewCell.m
//  iOSBlogReader
//
//  Created by everettjf on 16/4/30.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "FavTableViewCell.h"

@implementation FavTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
