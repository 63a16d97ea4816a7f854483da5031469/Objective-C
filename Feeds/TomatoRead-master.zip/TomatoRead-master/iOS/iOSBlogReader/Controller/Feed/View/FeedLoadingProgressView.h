//
//  FeedLoadingProgressView.h
//  iOSBlogReader
//
//  Created by everettjf on 16/5/1.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedLoadingProgressView : UIView


@end
