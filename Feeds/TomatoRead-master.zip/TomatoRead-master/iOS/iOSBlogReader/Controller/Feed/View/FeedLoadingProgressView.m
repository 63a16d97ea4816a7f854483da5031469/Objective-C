//
//  FeedLoadingProgressView.m
//  iOSBlogReader
//
//  Created by everettjf on 16/5/1.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#import "FeedLoadingProgressView.h"

@implementation FeedLoadingProgressView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

@end
