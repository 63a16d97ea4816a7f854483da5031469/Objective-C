//
//  PrivateHeader.h
//  iOSBlogReader
//
//  Created by everettjf on 16/5/3.
//  Copyright © 2016年 everettjf. All rights reserved.
//

#ifndef PrivateHeader_h
#define PrivateHeader_h

#define kUMengKey @"111"
#define kBuglyAppId @"111"

#endif /* PrivateHeader_h */
